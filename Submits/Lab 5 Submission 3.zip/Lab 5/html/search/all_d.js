var searchData=
[
  ['queue_48',['Queue',['../classssuds_1_1_queue.html',1,'ssuds']]]
];
