var searchData=
[
  ['node_33',['node',['../classssuds_1_1_linked_list_1_1node.html',1,'ssuds::LinkedList&lt; T &gt;::node'],['../classssuds_1_1_linked_list_1_1node.html#a2e0ef6a4910411dea2a377bba3ec8075',1,'ssuds::LinkedList::node::node()']]]
];
