var searchData=
[
  ['node_83',['node',['../classssuds_1_1_linked_list_1_1node.html#a2e0ef6a4910411dea2a377bba3ec8075',1,'ssuds::LinkedList::node']]]
];
