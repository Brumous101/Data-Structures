#pragma once
#include <SFML/Graphics.hpp>
#include <ostream>

namespace ssuds
{
	///The Bouncer class. Provides graphics for the bouncing object.
	class Bouncer : public sf::CircleShape
	{
	protected:
		
		sf::Vector2f mPos;			// The center of the circle
		int mNumBounces;
		float mRadius;
	public:
		sf::Vector2f mVelocity;
		Bouncer(float center_x, float center_y, float radius, float vel_x = 0.0f, float vel_y = 0.0f);
		Bouncer();
		void update(float dt, int width, int height);
		void drawBounces(sf::RenderWindow& win, sf::Font& font);

		sf::Vector2f getVelocity();
		sf::Vector2f getPosition();


		bool operator > (const Bouncer& b) const
		{
			float currentBouncerVelocity;
			float otherBouncerVelocity;
			currentBouncerVelocity = sqrtf((mVelocity.x * mVelocity.x) + (mVelocity.y * mVelocity.y));
			otherBouncerVelocity = sqrtf((b.mVelocity.x * b.mVelocity.x) + (b.mVelocity.y * b.mVelocity.y));
			if (currentBouncerVelocity > otherBouncerVelocity)
			{
				return true;
			}
			else //otherBouncerVelocity > currentBouncerVelocity
			{
				return false;
			}
		}

		//float getSpeed();
		//Attempted making a separate function to no avail 
		bool operator < (const Bouncer& b) const
		{
			float currentBouncerVelocity;
			float otherBouncerVelocity;
			currentBouncerVelocity = sqrtf((mVelocity.x * mVelocity.x) + (mVelocity.y * mVelocity.y));
			otherBouncerVelocity = sqrtf((b.mVelocity.x * b.mVelocity.x) + (b.mVelocity.y * b.mVelocity.y));
			if (currentBouncerVelocity < otherBouncerVelocity)
			{
				return true;
			}
			else //otherBouncerVelocity < currentBouncerVelocity
			{
				return false;
			}
		}
	};
	std::ostream& operator<< (std::ostream& os, Bouncer& bouncerObject);
}
