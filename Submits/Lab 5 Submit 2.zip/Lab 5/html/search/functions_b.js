var searchData=
[
  ['shrink_72',['Shrink',['../classssuds_1_1_array_list.html#a646adf15b9f1422f2a668f4d7ece8856',1,'ssuds::ArrayList']]],
  ['size_73',['size',['../classssuds_1_1_array_list.html#a09a8017b51733753c018ad4e70ade2e1',1,'ssuds::ArrayList::size()'],['../classssuds_1_1_linked_list.html#adb7155ceb5a5da5551cb080e3c229195',1,'ssuds::LinkedList::size()']]]
];
