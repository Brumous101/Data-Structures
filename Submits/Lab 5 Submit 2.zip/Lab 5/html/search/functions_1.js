var searchData=
[
  ['begin_49',['begin',['../classssuds_1_1_array_list.html#a29d38b6e2574880f07422497f468ddd8',1,'ssuds::ArrayList::begin()'],['../classssuds_1_1_linked_list.html#ad3559cd0af6c9cf13fe03d0c1e164145',1,'ssuds::LinkedList::begin()']]]
];
