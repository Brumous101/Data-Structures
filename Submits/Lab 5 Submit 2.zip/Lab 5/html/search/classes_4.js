var searchData=
[
  ['queue_45',['Queue',['../classssuds_1_1_queue.html',1,'ssuds']]]
];
