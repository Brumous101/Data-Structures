var searchData=
[
  ['node_20',['node',['../classssuds_1_1_linked_list_1_1node.html',1,'ssuds::LinkedList']]]
];
