var searchData=
[
  ['clear_24',['clear',['../classssuds_1_1_linked_list.html#a5db25fa94ebc906c2ec5a4bcd430da38',1,'ssuds::LinkedList']]]
];
