var searchData=
[
  ['queue_21',['Queue',['../classssuds_1_1_queue.html',1,'ssuds']]]
];
