//Name: Kyle Johnson
//Class: ETEC2101
//Section: 01
//Assignment: 5
#pragma once
namespace ssuds
{
	template<class T>
	///The Queue class provides functions that act as a queue
	class Queue: protected LinkedList<T> //want protected functions
	{
	public:
		void push(T val)
		{
			this->push_back(val);
		}
		T peek()
		{
			return (*this)[0];// LinkedList<T>::mData[0];
		}
		T pop()
		{
			return this ->remove(0);
		}
		bool empty()
		{
			if (LinkedList<T>::mSize == 0)
			{
				return true;
			}
			else//(LinkedList<T>::mSize != 0)
			{
				return false;
			}
		}
	};
}