//Name: Kyle Johnson
//Class: ETEC2101
//Section: 01
//Assignment: 5
#pragma once
/*
push adds
pop removes
peek returns the value
empty tells if there is stuff to pop
*/

namespace ssuds
{
	template<class T>
	class Stack : protected LinkedList<T> //want protected functions
	{
	public:
		void push(T val)
		{
			this->push_front(val);
		}
		T peek()
		{
			return (*this)[0];// LinkedList<T>::mData[0];
		}
		T pop()
		{
			return this->remove(0);
		}
		bool empty()
		{
			if (LinkedList<T>::mSize == 0)
			{
				return true;
			}
			else//(LinkedList<T>::mSize != 0)
			{
				return false;
			}
		}
	};
}